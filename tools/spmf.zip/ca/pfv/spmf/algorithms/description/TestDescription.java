package ca.pfv.spmf.algorithms.description;

public class TestDescription {

	public static void main(String[] args) {
		DescriptionAlgoBIDEPlus description = new DescriptionAlgoBIDEPlus();
		
		System.out.println(description.getName());
		
	}

}
